@API(apiVersion=AbyssalCraftAPI.API_VERSION,owner="abyssalcraft",provides="AbyssalCraftAPI")
package com.shinoow.abyssalcraft.api.item;
import net.minecraftforge.fml.common.API;
import com.shinoow.abyssalcraft.api.AbyssalCraftAPI;