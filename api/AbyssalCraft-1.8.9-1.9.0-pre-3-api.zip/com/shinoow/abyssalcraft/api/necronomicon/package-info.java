@API(apiVersion=AbyssalCraftAPI.API_VERSION,owner="abyssalcraft",provides="AbyssalCraftAPI|Necronomicon")
package com.shinoow.abyssalcraft.api.necronomicon;
import net.minecraftforge.fml.common.API;
import com.shinoow.abyssalcraft.api.AbyssalCraftAPI;