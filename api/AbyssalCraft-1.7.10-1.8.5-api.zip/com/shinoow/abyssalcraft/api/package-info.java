@API(apiVersion=AbyssalCraftAPI.API_VERSION,owner="abyssalcraft",provides="AbyssalCraftAPI")
package com.shinoow.abyssalcraft.api;
import cpw.mods.fml.common.API;