@API(apiVersion=AbyssalCraftAPI.API_VERSION,owner="abyssalcraft",provides="AbyssalCraftAPI|Core")
package com.shinoow.abyssalcraft.api;
import net.minecraftforge.fml.common.API;