@API(apiVersion=AbyssalCraftAPI.API_VERSION,owner="abyssalcraft",provides="AbyssalCraftAPI")
package com.shinoow.abyssalcraft.api.block;
import com.shinoow.abyssalcraft.api.AbyssalCraftAPI;
import cpw.mods.fml.common.API;
