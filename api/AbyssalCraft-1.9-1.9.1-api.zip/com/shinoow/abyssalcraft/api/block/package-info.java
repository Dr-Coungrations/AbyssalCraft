@API(apiVersion=AbyssalCraftAPI.API_VERSION,owner="abyssalcraft",provides="AbyssalCraftAPI|Block")
package com.shinoow.abyssalcraft.api.block;
import net.minecraftforge.fml.common.API;
import com.shinoow.abyssalcraft.api.AbyssalCraftAPI;