@API(apiVersion=AbyssalCraftAPI.API_VERSION,owner="abyssalcraft",provides="AbyssalCraftAPI|Disruption")
package com.shinoow.abyssalcraft.api.energy.disruption;
import net.minecraftforge.fml.common.API;
import com.shinoow.abyssalcraft.api.AbyssalCraftAPI;