@API(apiVersion=AbyssalCraftAPI.API_VERSION,owner="abyssalcraft",provides="AbyssalCraftAPI|Ritual")
package com.shinoow.abyssalcraft.api.ritual;
import net.minecraftforge.fml.common.API;
import com.shinoow.abyssalcraft.api.AbyssalCraftAPI;