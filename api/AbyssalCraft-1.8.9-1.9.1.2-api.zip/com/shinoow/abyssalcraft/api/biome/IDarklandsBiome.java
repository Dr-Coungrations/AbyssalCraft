package com.shinoow.abyssalcraft.api.biome;

/**
 * Interface to define a Darklands biome
 * 
 * @author shinoow
 * 
 * @since 1.7
 */
public interface IDarklandsBiome {

}
