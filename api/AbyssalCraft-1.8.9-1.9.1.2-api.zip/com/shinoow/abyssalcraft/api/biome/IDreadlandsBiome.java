package com.shinoow.abyssalcraft.api.biome;

/**
 * Interface to define a Dreadlands biome
 * 
 * @author shinoow
 * 
 * @since 1.7
 */
public interface IDreadlandsBiome {

}
